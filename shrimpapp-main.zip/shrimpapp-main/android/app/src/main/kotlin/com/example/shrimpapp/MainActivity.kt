package com.example.shrimpapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
